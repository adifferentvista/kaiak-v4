---
title: "How I Use AI to Prepare for Difficult Conversations"
date: "2025-01-07"
description: "Difficult conversations used to keep me up at night. Now I use AI to prepare, practice, and process them. Here's my system."
category: "Practical AI"
---

The conversation I was dreading sat on my calendar for three days.

I had to tell a teacher that their contract wouldn't be renewed. They weren't a bad person. They just weren't right for the role, and a year of coaching hadn't changed that.

I knew what I needed to say. I'd drafted talking points. But I couldn't stop rehearsing it in my head — imagining their reaction, anticipating their questions, worrying I'd say the wrong thing.

This is the part of leadership nobody trains you for. The difficult conversations. The ones that keep you up at night.

I've since developed a system using AI that helps me prepare for these conversations. It doesn't make them easy. But it makes them easier. And it helps me show up as the leader I want to be instead of the anxious mess I feel like inside.

## Why Difficult Conversations Are Hard

Let's be honest about what makes them hard:

**Emotional activation.** Your body goes into threat mode. Heart rate up. Palms sweaty. Thinking cloudy. You're not at your best.

**Unpredictability.** You can't control how the other person will react. They might cry. They might get angry. They might say something that throws you off completely.

**Stakes.** These conversations matter. A wrong word can damage a relationship, create legal risk, or escalate conflict.

**Isolation.** You can't easily practice with someone else. HR might not be available. And you don't want to rehearse with colleagues who might gossip.

AI doesn't solve all of these. But it helps with one critical piece: preparation.

## The Preparation System

Here's how I use AI to prepare for difficult conversations:

### Step 1: Brain Dump

First, I get everything out of my head. I open a chat and just dump:

"I need to have a conversation with [role/context]. The situation is [what happened]. I'm feeling [emotions]. I'm worried about [concerns]. The outcome I need is [goal]."

This isn't a polished prompt. It's a brain dump. The goal is to externalize the swirl in my head so I can look at it clearly.

### Step 2: Get a Framework

Next, I ask AI for a structure:

"Help me structure this conversation. What should I cover, and in what order? Keep it simple — no more than 4-5 parts."

AI usually gives me something like:
1. Open with intention
2. Share the observation/concern
3. Listen to their perspective
4. Discuss path forward
5. Close with clarity on next steps

I adjust based on my context, but having a framework calms me down. I'm not winging it. I have a map.

### Step 3: Draft Key Phrases

This is where AI really helps. I ask:

"Give me specific phrases I could use to [open the conversation / share the difficult news / respond if they get defensive]. Keep them direct but compassionate."

For example, for opening a contract non-renewal conversation:

- "I want to be direct with you because I respect you."
- "This is a hard conversation, and I've given it a lot of thought."
- "I need to share a decision, and then I want to hear your perspective."

Having pre-drafted phrases means I'm not searching for words in the moment. I can stay present instead of panicking about what to say next.

### Step 4: Anticipate Reactions

I ask AI to help me prepare for different scenarios:

"What are the most likely ways this person might react? For each reaction, give me a brief response that acknowledges their feeling while staying on track."

This might generate:

**If they get angry:** "I understand you're frustrated. That's a natural response. I want to give you space to process this."

**If they cry:** "Take whatever time you need. This is hard news, and your reaction makes sense."

**If they argue or deny:** "I hear that you see it differently. My decision is based on [specific observations]. I'm not asking you to agree, but I need you to understand where I am."

**If they shut down:** "I can see this is a lot to take in. We don't have to resolve everything today. Let's schedule a follow-up."

Rehearsing these responses means I'm less likely to be thrown off.

### Step 5: Practice Out Loud

This step doesn't require AI, but it's essential.

I take the key phrases and practice saying them out loud. Alone, in my office, feeling awkward. 

The first time you say difficult words shouldn't be in the actual conversation. Your mouth needs to know how to form them. Practicing out loud makes the real conversation 50% easier.

### Step 6: Post-Conversation Processing

After the conversation, I use AI to process:

"I just had [conversation]. Here's what happened: [summary]. What went well: [what worked]. What I wish I'd done differently: [reflection]. Help me identify lessons for next time."

This turns every difficult conversation into a learning opportunity. Over time, I've gotten better at these conversations — not because I'm naturally good at them, but because I systematically improve.

## Example: Addressing Chronic Lateness

Here's a simpler example — addressing a staff member who's consistently late to meetings.

**My brain dump:**
"Sarah has been 10-15 minutes late to the last four leadership team meetings. It's disruptive and others have noticed. I don't want to make a huge deal of it, but I need it to stop. I'm worried she'll get defensive or think I'm micromanaging."

**Framework AI suggested:**
1. Name the pattern specifically
2. Share the impact
3. Ask for her perspective
4. Agree on the expectation going forward
5. Express confidence in her

**Key phrases AI helped me draft:**
- "I want to talk about something I've noticed. In the last four leadership meetings, you've arrived 10-15 minutes late."
- "When that happens, we either wait and lose time, or we start without you and you miss context. It's creating friction."
- "I'm not trying to micromanage your calendar. I'm asking because these meetings matter and we need everyone present from the start."
- "What's getting in the way?"

**The actual conversation** took 8 minutes. Sarah apologized, explained she'd been scheduling parent calls right before meetings, and committed to blocking buffer time. No drama. No defensiveness.

The preparation took longer than the conversation. That's the point.

## What AI Can't Do

To be clear about the limits:

**AI can't read the room.** In the actual conversation, you need to pay attention to the human in front of you. Their body language. Their tone. What they're not saying. AI helps you prepare; it doesn't help you be present.

**AI can't feel for you.** These conversations are hard because they involve real emotions — yours and theirs. AI can help you articulate, but you still have to feel through it.

**AI can't make it painless.** A well-prepared difficult conversation is still difficult. You'll still feel nervous. You might still say something imperfect. That's okay. The goal isn't perfection. The goal is to show up as well as you can.

**AI shouldn't replace human support.** For high-stakes conversations (terminations, legal issues, serious conflicts), you should still involve HR, your board chair, or other appropriate support. AI is for preparation, not for replacing professional guidance.

## The Conversations I Use This For

Over the past year, I've used this system for:

- Contract non-renewals
- Performance concerns
- Parent complaints that escalated
- Board member disagreements
- Delivering bad news (budget cuts, program changes)
- Addressing interpersonal conflicts on teams
- Having boundaries conversations with people who overstep

Every one of them went better than it would have without preparation. Not perfect. But better.

## The Shift

The biggest change isn't tactical. It's psychological.

Difficult conversations used to feel like threats. Something to avoid, postpone, dread. Now they feel like problems to solve. Still not fun. But manageable.

The system gives me a sense of control. I can't control how the other person will react. But I can control how prepared I am. That's enough to change my relationship with these conversations.

---

If you're leading a team and struggling with the human side of leadership — the conversations, the conflicts, the hard decisions — you're not alone. [Book a conversation](/booking) if you want to talk through what you're facing.
