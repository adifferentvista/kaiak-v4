---
title: "The Parent Communication System That Eliminated Complaints"
date: "2025-01-28"
description: "Parent complaints dropped 70% after I implemented this communication system. Most complaints aren't about problems — they're about uncertainty."
category: "Systems Thinking"
---

In my first year as Head, parent complaints consumed hours of my week.

Not big complaints about education quality or safety — small complaints. Why didn't we know about this earlier? Who made that decision? Why wasn't anyone told?

The complaints weren't really about the content. They were about the communication.

Once I realized that, everything changed.

## The Real Problem

Here's what I learned: most parent complaints are actually about uncertainty.

When parents don't know what's happening, they fill the void with anxiety. When they feel surprised by decisions, they feel disrespected. When they hear about something from their child instead of the school, they feel out of the loop.

The complaints that land on a Head's desk are usually the visible symptom of invisible communication gaps.

**What they say:** "Why wasn't I told about the schedule change?"

**What they mean:** "I don't feel like I know what's happening at this school, and that makes me anxious."

**What they say:** "Who decided to cancel the field trip?"

**What they mean:** "I feel like decisions are made without my input or awareness, and that feels disrespectful."

**What they say:** "This is unacceptable."

**What they mean:** "I'm worried about my child, and I don't trust that you're communicating everything I need to know."

The solution isn't better responses to complaints. It's proactive communication that prevents the complaints from forming.

## The Communication System

I built a parent communication system with four components:

### Component 1: The Weekly Rhythm

Every Friday, parents receive one email from the school. One.

Not multiple emails from different departments. Not sporadic updates when things happen. One consolidated weekly update.

The format:
- **What happened this week** (2-3 highlights)
- **What's coming next week** (schedule, events, deadlines)
- **Decisions made** (anything parents should know about)
- **Action items** (anything that requires parent response)

That's it. Consistent. Predictable. Comprehensive.

Why Friday? Because parents plan their weekends and weeks ahead. Friday gives them what they need when they're thinking about it.

Why one email? Because multiple emails train parents to skim or ignore. A single, reliable source gets read.

### Component 2: The Advance Notice Rule

Nothing surprises parents. That's the rule.

For any decision or change that affects families, we communicate at least 48 hours in advance. Ideally a week. No same-day announcements unless it's a genuine emergency.

This required discipline. Teachers would often want to announce things the day before. "Can you send this out today?" No. Not unless it's urgent. We plan ahead.

The advance notice rule eliminated the single most common complaint: "Why didn't anyone tell us?"

### Component 3: The Decision Explanation

When we make a decision that affects families, we don't just announce it. We explain it.

The format:
- **What we decided**
- **Why we decided it**
- **What we considered**
- **How it affects you**

This sounds obvious. But most school communications announce decisions without context. Parents are left wondering why — and when people wonder why, they often assume the worst.

Example:

**Bad:** "Due to scheduling constraints, the Grade 4 field trip has been moved to March 15."

**Good:** "We've moved the Grade 4 field trip to March 15. We made this change because the original date conflicted with district testing, which would have meant some students couldn't attend. The new date works for all families who responded to the permission slip. If March 15 creates a conflict for your family, please contact [teacher] by [date]."

The second version takes 30 more seconds to write. It prevents hours of confused emails and irritated phone calls.

### Component 4: The Feedback Channel

Parents need a way to give feedback that doesn't require complaining.

We created:
- A quarterly parent survey (5 questions, takes 3 minutes)
- An open "suggestions" form on the parent portal
- Twice-yearly parent listening sessions (small groups, open agenda)

These channels served two purposes:

**Early warning:** We heard about problems before they became complaints. A parent who's slightly annoyed will fill out a survey. A parent who's furious will email the Head.

**Feeling heard:** Even when we couldn't act on feedback, parents appreciated being asked. The act of soliciting input builds trust.

## The Results

After implementing this system:

- Parent complaints to my office dropped roughly 70%
- "Why didn't anyone tell us" emails almost disappeared
- Survey satisfaction with communication increased significantly
- Staff reported fewer difficult parent interactions

The time invested in proactive communication was far less than the time previously spent on reactive complaint management.

## Why This Works

The system works because it addresses the root cause of complaints: uncertainty.

**Weekly rhythm** → Parents know when to expect information
**Advance notice** → Parents aren't surprised
**Decision explanation** → Parents understand the reasoning
**Feedback channels** → Parents feel heard

Certainty reduces anxiety. Reduced anxiety reduces complaints.

## Common Objections

**"We don't have time to write a weekly update."**

It takes 30-45 minutes once you have a template. That's less time than you'll spend responding to the complaints you'll get without it.

Also: this can be delegated. The Head doesn't need to write it. A communications coordinator, EA, or principal can manage it. The Head just reviews before it goes out.

**"Parents will still complain."**

Some will. But fewer. And when they do, you can point to the communication they received: "This was included in our Friday update on [date]. Let me know if those emails aren't reaching you."

This isn't about eliminating complaints. It's about eliminating preventable complaints.

**"We already send too much communication."**

Probably true. That's why I advocate consolidating to one weekly email, not adding more. Less frequent, more comprehensive communication is better than constant piecemeal updates.

**"Different divisions need different communication."**

Fine. Have division-specific sections within the weekly update. Or have one school-wide update and one divisional update. Just maintain predictable rhythm for each.

## Setting It Up

If you want to implement this:

**Week 1:** Audit your current parent communication. How many emails go out weekly? From how many sources? What's predictable vs. ad hoc?

**Week 2:** Design your weekly update template. What sections do you need? Who contributes what? Who owns the final product?

**Week 3:** Announce the new system to parents. "Starting [date], you'll receive one comprehensive weekly update every Friday. This replaces the various emails you've been getting from different departments."

**Week 4:** Send your first weekly update. It won't be perfect. Iterate.

**Ongoing:** Establish the 48-hour advance notice rule with staff. This requires training and reminders.

## The Deeper Principle

Parent communication is really about trust.

When parents trust the school, they give you the benefit of the doubt. They assume good intentions. They bring concerns to you before they escalate.

When parents don't trust the school, they assume the worst. They gossip with other parents. They go to the board.

Trust is built through consistent, transparent, proactive communication. It's eroded through surprises, silence, and unexplained decisions.

The system I've described isn't complicated. It's just disciplined. And that discipline, maintained over months and years, creates a fundamentally different relationship with your parent community.

---

If you're struggling with parent communication and want help building a system like this, [let's talk](/booking). Communication infrastructure is one of the foundations I help school leaders build.
