---
title: "The Board Report Template That Changed My Governance Relationship"
date: "2025-01-02"
description: "I used to dread board meetings. Then I changed how I reported to them. One template transformed a tense relationship into a productive partnership."
category: "Systems Thinking"
---

For my first two years as Head, I dreaded board meetings.

Not because the board was bad — they were reasonable people who cared about the school. But our meetings felt adversarial. They'd ask questions I wasn't prepared for. I'd give long explanations that satisfied no one. We'd leave with vague action items that nobody tracked.

The problem wasn't the board. It was how I was communicating with them.

Once I changed my reporting structure, everything shifted. Meetings got shorter. Questions got easier. Trust increased. I actually started looking forward to board meetings — or at least not dreading them.

Here's the template that made the difference.

## The Problem With Most Board Reports

Most Head-to-Board reporting falls into one of two traps:

**Trap 1: The Information Dump**

You send the board everything. Enrollment spreadsheets. Department updates. Event calendars. Financial statements. Forty pages of attachments.

The board skims it, retains nothing, and asks basic questions you thought you'd answered. Then you feel frustrated that they didn't read the materials.

**Trap 2: The Vague Update**

You send a narrative summary. "Things are going well. We're making progress on our initiatives. There are some challenges but we're addressing them."

The board has no idea what's actually happening. They fill the void with their own assumptions and anxieties. Then they ask probing questions that feel like interrogation.

Both traps create the same result: a board that doesn't feel informed and a Head who feels defensive.

## The One-Page Board Report

The solution is radical simplicity. One page. Every month. Same structure.

Here's the template:

---

**BOARD REPORT — [Month, Year]**

**1. KEY METRICS** (5 lines max)
- Enrollment: [Current] vs [Budget] vs [Last Year]
- Retention: [%] 
- Staff: [Headcount], [Open positions], [Recent departures]
- Financials: [Revenue vs budget], [Key variance]
- Safety: [Incidents this month]

**2. STRATEGIC PRIORITIES** (3-5 priorities, 1 line each)

| Priority | Status | Note |
|----------|--------|------|
| [Priority 1] | 🟢 On Track | [One sentence update] |
| [Priority 2] | 🟡 At Risk | [One sentence on why] |
| [Priority 3] | 🟢 On Track | [One sentence update] |

**3. WINS THIS MONTH** (2-3 bullets)
- [Specific accomplishment]
- [Specific accomplishment]

**4. CONCERNS** (1-3 bullets)
- [Issue]: [What we're doing about it]
- [Issue]: [What we're doing about it]

**5. DECISIONS NEEDED FROM BOARD** (if any)
- [Decision]: [Context in one sentence]. Recommendation: [Your recommendation].

**6. COMING UP**
- [Key dates/events in next 30 days]

---

That's it. One page. Takes 20 minutes to prepare once you have the rhythm.

## Why This Works

### It respects their time

Board members are busy. They're volunteering their time to govern your school. They don't want to read 40 pages. They want to know: are we on track? What should I be worried about? What do you need from me?

The one-page format answers those questions and nothing else.

### It forces you to prioritize

When you only have one page, you can't include everything. You have to decide what matters.

This is a feature, not a bug. If you can't fit it on one page, you probably haven't clarified your own thinking yet. The constraint forces clarity.

### It sets the agenda

When you send a clear report, you control the conversation. The board discusses what you've surfaced, not what they're anxious about.

Without a clear report, board members fill the void. They bring up random concerns, old issues, things they heard from parents. You spend the meeting playing defense.

With a clear report, you play offense. You've already named the concerns. You've already shared your plan. The conversation is productive.

### It builds trust through transparency

Notice that the template includes "Concerns" as a required section.

Most Heads hide problems from their boards, hoping to solve them before anyone notices. This backfires. When boards discover problems you didn't tell them about, they lose trust. They start wondering what else you're hiding.

By proactively sharing concerns — with your plan to address them — you build trust. You're saying: "I see the problems. I'm on it. I'm not hiding anything."

Boards don't expect perfection. They expect honesty and competence. This template demonstrates both.

## How to Use It

### Preparation rhythm

I prepare my board report on the last Friday of each month. It takes about an hour total:

- 15 min: Pull the metrics (I have a dashboard that tracks these)
- 15 min: Update strategic priority status
- 15 min: Write the wins, concerns, and decisions needed
- 15 min: Review and tighten

If you don't have systems to track your metrics, the first few months will take longer. But that's a sign you need those systems anyway.

### Sending it

I send the report 48 hours before the board meeting. Not a week early (they'll forget it), not the day before (they won't have time to read it).

48 hours is enough time to read it, think about it, and come to the meeting with informed questions.

### In the meeting

I don't present the report. They've read it. Instead, I say:

"You've seen the report. I'm happy to answer questions on any section, or we can go straight to the decisions we need to make together."

This signals respect for their preparation and moves the meeting forward.

### After the meeting

I send a brief follow-up within 24 hours:

"Thanks for the discussion tonight. Decisions made: [list]. Action items: [list with owners and deadlines]. Next meeting: [date]."

This closes the loop and creates accountability.

## Adapting the Template

The template above is a starting point. Adapt it to your context:

**If your board is metrics-focused:** Expand the metrics section, add trend lines, include comparisons to benchmarks.

**If your board is relationship-focused:** Add a "Community Pulse" section with qualitative feedback from parents, students, staff.

**If your board micromanages:** The template actually helps with this. Micromanagement usually comes from anxiety about not knowing what's happening. Consistent, transparent reporting reduces that anxiety over time.

**If you have a large board:** Consider a brief "consent agenda" for routine items that don't need discussion, saving meeting time for strategic conversations.

## What Changed for Me

After six months of using this template, my board meetings transformed:

**Before:**
- 3-hour meetings
- Defensive question-answering
- Vague action items
- Tension and frustration

**After:**
- 90-minute meetings
- Focused strategic discussions
- Clear decisions with owners
- Collaborative relationship

The board started saying things like "I feel like I actually know what's happening now" and "These reports are so clear."

More importantly, when problems arose, they trusted me to handle them. I'd earned that trust through consistent transparency.

## The Deeper Lesson

The board report template is really about something bigger: controlling your narrative.

As Head, you're constantly being evaluated. By the board, by parents, by staff. If you don't tell your story clearly, others will tell it for you — and they'll get it wrong.

The one-page report is a discipline of narrative control. Every month, you're saying: here's what matters, here's where we are, here's what I need. You're shaping how the board sees the school and your leadership.

That's not spin. It's clarity. And clarity builds trust.

---

If you're struggling with your board relationship and want help building systems like this, [let's talk](/booking). Governance alignment is one of the first things I work on with new Heads.
