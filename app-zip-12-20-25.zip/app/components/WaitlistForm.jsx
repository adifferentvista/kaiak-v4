'use client';

import { useState } from 'react';

const CONVERTKIT_FORM_ID = '8895758'; // Guide Waitlist form

export default function WaitlistForm() {
  const [email, setEmail] = useState('');
  const [honeypot, setHoneypot] = useState('');
  const [status, setStatus] = useState('idle'); // idle, loading, success, error
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Honeypot check - if filled, it's a bot
    if (honeypot) {
      setStatus('success');
      setMessage("You're on the waitlist!");
      return;
    }
    
    if (!email.trim()) return;

    setStatus('loading');

    try {
      const formData = new FormData();
      formData.append('email_address', email);
      
      const response = await fetch(
        `https://app.convertkit.com/forms/${CONVERTKIT_FORM_ID}/subscriptions`,
        {
          method: 'POST',
          body: formData,
        }
      );

      // Success
      setStatus('success');
      setMessage("You're on the waitlist! We'll email you when it launches.");
      setEmail('');

    } catch (error) {
      // ConvertKit might redirect on success, treat as success
      setStatus('success');
      setMessage("You're on the waitlist! We'll email you when it launches.");
      setEmail('');
    }
  };

  if (status === 'success') {
    return (
      <div className="px-4 py-3 rounded-lg bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 text-sm text-center">
        ✓ {message}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {/* Honeypot field */}
      <input
        type="text"
        name="website"
        value={honeypot}
        onChange={(e) => setHoneypot(e.target.value)}
        className="absolute -left-[9999px]"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
      />
      
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@company.com"
        required
        disabled={status === 'loading'}
        className="w-full px-4 py-3 rounded-lg border border-slate-200 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-800 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 disabled:opacity-50"
        aria-label="Email address"
      />
      <button
        type="submit"
        disabled={status === 'loading'}
        className="w-full text-white px-6 py-3 rounded-lg font-medium bg-amber-500 text-navy hover:bg-amber-400 theme-transition disabled:opacity-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2"
      >
        {status === 'loading' ? 'Joining...' : 'Join the Waitlist'}
      </button>
      
      {status === 'error' && (
        <p className="text-red-500 text-sm text-center">{message}</p>
      )}
      
      <p className="text-xs text-slate-400 dark:text-slate-500 text-center">
        Be first to know when it launches. No spam.
      </p>
    </form>
  );
}
